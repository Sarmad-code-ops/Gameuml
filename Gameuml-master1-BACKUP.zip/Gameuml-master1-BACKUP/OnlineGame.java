
/**
 * Write a description of class OnlineGame here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class OnlineGame extends MultiPlayerGame
{
    // instance variables - replace the example below with your own
    private int x;
    public String serverRegion;
    public boolean subscription;

    /**
     * Constructor for objects of class OnlineGame
     */
    public OnlineGame(String title, Genre genre, Platform platform, AgeRating ageRating, boolean multiplayer,String serverRegion, boolean subscription)
    {
        super(title, genre, platform, ageRating, multiplayer);  
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public int sampleMethod(int y)
    {
        // put your code here
        return x + y;
    }
}