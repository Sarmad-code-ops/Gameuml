
/**
 * Write a description of class singleplayergame here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class SinglePlayerGame extends Game
{
   private boolean hasCampaign;
   
   public SinglePlayerGame(String title, Genre genre,Platform platform, AgeRating ageRating, boolean hasCampaign) {
       super(title,genre,platform,ageRating);
       this.hasCampaign = hasCampaign;
   }
   public String getDetails() {
       return super.getDetails() + " | Campaign: " + hasCampaign;
   }
}