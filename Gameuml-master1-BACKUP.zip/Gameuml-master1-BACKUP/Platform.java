public enum Platform{
    MOBILE, PC, CONSOLE, VR
}