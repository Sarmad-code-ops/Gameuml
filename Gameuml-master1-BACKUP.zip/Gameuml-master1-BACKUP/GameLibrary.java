import java.util.ArrayList;

/**
 * Write a description of class GameLibrary here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class GameLibrary
{
    private ArrayList <Game> games;
    
    public GameLibrary(){
        games = new ArrayList <Game>();
    }
    
}