
/**
 * Write a description of class multiplayergame here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class MultiPlayerGame extends Game
{
    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructor for objects of class multiplayergame
     */
    public MultiPlayerGame(String title, Genre genre,Platform platform, AgeRating ageRating, boolean hasCampaign)
    {
        super(title,genre,platform,ageRating);
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public int sampleMethod(int y)
    {
        // put your code here
        return x + y;
    }
}